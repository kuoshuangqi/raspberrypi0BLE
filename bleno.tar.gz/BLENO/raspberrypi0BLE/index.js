var Bleno = require('./lib/bleno');

module.exports = new Bleno();
