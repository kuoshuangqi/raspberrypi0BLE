get data from sensor and notify out by BLE 123
